import csv

# Create the employee personal information CSV file
with open('employee_personal_data.csv', 'w', newline='') as csvfile:
    fieldnames = ['emp_id', 'emp_fullname', 'emp_age', 'emp_gender', 'emp_mobile', 'emp_address', 'emp_email']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

    writer.writeheader()
    # Add data to the CSV file
    writer.writerow({'emp_id': 10, 'emp_fullname': 'Rahul', 'emp_age': 25, 'emp_gender': 'M', 'emp_mobile': '5446465464', 'emp_address': '4965 pani Street', 'emp_email': 'Rahul@gmail.com'})
    writer.writerow({'emp_id': 20, 'emp_fullname': 'Ram', 'emp_age': 45, 'emp_gender': 'F', 'emp_mobile': '544544321', 'emp_address': '4555 puri Street', 'emp_email': 'ram@gmail.com'})

# Create the employee company details CSV file
with open('employee_company_details.csv', 'w', newline='') as csvfile:
    fieldnames = ['emp_id', 'emp_designation', 'emp_joined', 'emp_status', 'emp_department']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

    writer.writeheader()
    # Add data to the CSV file
    writer.writerow({'emp_id': 10, 'emp_designation': 'assi_devloper', 'emp_joined': '2020-01-01', 'emp_status': 'Active', 'emp_department': 'HR'})
    writer.writerow({'emp_id': 20, 'emp_designation': 'Assi_Manager', 'emp_joined': '2022-01-01', 'emp_status': 'Active', 'emp_department': 'Marketing'})

# Create the employee salary details CSV file
with open('employee_salary_details.csv', 'w', newline='') as csvfile:
    fieldnames = ['emp_id', 'emp_salary', 'emp_net_salary', 'emp_tax', 'emp_pf', 'emp_health_amount']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

    writer.writeheader()
    # Add data to the CSV file
    writer.writerow({'emp_id': 10, 'emp_salary': 5000, 'emp_net_salary': 4000, 'emp_tax': 100, 'emp_pf': 200, 'emp_health_amount': 100})
    writer.writerow({'emp_id': 20, 'emp_salary': 4000, 'emp_net_salary': 3500, 'emp_tax': 500, 'emp_pf': 150, 'emp_health_amount': 50})

print("Csv File created")

