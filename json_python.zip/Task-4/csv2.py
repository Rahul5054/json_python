import csv

# Read the employee personal information CSV file
with open('employee_personal_data.csv', 'r') as csvfile:
    reader = csv.DictReader(csvfile)
    personal_data = list(reader)

# Read the employee company details CSV file
with open('employee_company_details.csv', 'r') as csvfile:
    reader = csv.DictReader(csvfile)
    company_data = list(reader)

# Read the employee salary details CSV file
with open('employee_salary_details.csv', 'r') as csvfile:
    reader = csv.DictReader(csvfile)
    salary_data = list(reader)

# Merge the data from the three CSV files
employee_data = []
for personal in personal_data:
    emp_id = personal['emp_id']
    employee = personal
    for company in company_data:
        if company['emp_id'] == emp_id:
            employee.update(company)
            break
    for salary in salary_data:
        if salary['emp_id'] == emp_id:
            employee.update(salary)
            break
    employee_data.append(employee)

# Write the merged data to a new CSV file
with open('employee_details.csv', 'w', newline='') as csvfile:
    fieldnames = ['emp_id', 'emp_fullname', 'emp_age', 'emp_gender', 'emp_mobile', 'emp_address', 'emp_email', 'emp_designation', 'emp_joined', 'emp_status', 'emp_department', 'emp_salary', 'emp_net_salary', 'emp_tax', 'emp_pf', 'emp_health_amount']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

    writer.writeheader()
    writer.writerows(employee_data)

with open('employee_details.csv', 'r') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        print(row)