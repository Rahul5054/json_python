import json
import mysql.connector

# Load the JSON data from the file
with open('userinfo.json', 'r') as f:
    data = json.load(f)

# Connect to the database
cnx = mysql.connector.connect(user='root', password='root', host='localhost', database='mydatabase')
cursor = cnx.cursor()
def insert():
    cursor = cnx.cursor()

    # Load the JSON data from the file
    with open('userinfo.json', 'r') as f:
        data = json.load(f)

        # Insert the data into the database
    for item in data['details']:
        query = "INSERT INTO emp2 (firstname, lastname, email, mobileno, address) VALUES (%s, %s, %s, %s, %s)"
        values = (item['firstname'], item['lastname'], item['email'], item['mobileno'], item['address'])
        cursor.execute(query, values)
    print("record Success")
    cnx.commit()
    cnx.close()
# insert()


def delete():


# Delete a record from the database
    e=input("Enter mail: ")
    cursor = cnx.cursor()

    # Issue a SELECT query to search for the data
    query = f"SELECT * FROM emp2 WHERE email='{e}'"
    cursor.execute(query)

    # Check if the query returned any results
    for item in data['details']:
        if cursor.fetchone():
            print("Value found in database")
            query = f"DELETE FROM emp2 WHERE email = '{e}'"
            cursor.execute(query)
            print("Deleted Successfully")
            cnx.commit()
            break
        else:
            print("Value not found in database")
            break

    # Close the cursor and connection
cursor.close()

delete()