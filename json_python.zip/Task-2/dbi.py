import json
import mysql.connector

# Connect to the database
cnx = mysql.connector.connect(
  host="localhost",
  user="root",
  password="root",
  database="mydatabase"
)
cursor = cnx.cursor()

# Load the JSON data from the file
with open('userinfo.json','r') as f:
    data = json.load(f)

    # Insert the data into the database
for item in data['details']:
    query = "INSERT INTO emp2 (firstname, lastname, email, mobileno, address) VALUES (%s, %s, %s, %s, %s)"
    values = (item['firstname'], item['lastname'], item['email'], item['mobileno'], item['address'])
    cursor.execute(query, values)
print("record Success")
cnx.commit()
cnx.close()
# insert()
