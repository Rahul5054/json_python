import json
import re
def add():
# create an empty list of users

    with open('userinfo.json', 'r+') as f:
        u=json.load(f)

    while True:
        def fname():
            global first_name
            first_name = input("Enter first name : ")
            if re.match(r'^[a-zA-Z\s]+$', first_name):
                print("valid input")
            else:
                print("invalid input")
                fname()

        fname()

        def lname():
            global last_name
            last_name = input("Enter last name : ")
            if re.match(r'^[a-zA-Z\s]+$', last_name):
                print("valid string")
            else:
                print("invalid input")
                lname()

        lname()

        def mail():
            global email
            email = input("Enter email: ")
            # Use a regular expression to check if the email address is valid
            pattern = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
            if re.match(pattern, email):
                print("Valid email address")
            else:
                print("Invalid email address")
                mail()

        mail()

        def goto():
            global mobile_no
            mobile_no = input("Enter mobile number: ")
            pattern = r"^\d{10}$"
            if re.match(pattern, mobile_no):
                print("valid number")
            else:
                print("invalid number")
                goto()

        goto()
        address = input("Enter address: ")

        # create a new user
        new_data ={
            "firstname": first_name,
            "lastname": last_name,
            "email": email,
            "mobileno": mobile_no,
            "address": address
        }
        result=[u["details"].append(new_data)]
        # file_data["emp_details"].append(new_data)
        # check if the email id of the new user already exists in the list
        with open('userinfo.json', 'r') as f:
            um=json.load(f)
        for user in um['details']:
            if user['email']==email:
                print("User Already exists!")
                break
            else:
                # add the new user to the list of users
                pass


        # ask the user if they want to add more users
        add_more = input("Do you want to add more users? (y/n) ")
        if add_more.lower() == 'n':
            # write the list of users to a JSON file
            with open('userinfo.json', 'w') as f:
                json.dump(u, f)
            break

def delete():
    with open('userinfo.json', 'r+') as f:
        u=json.load(f)

    # Prompt the user to enter the email address of the user they want to delete
    email = input("Enter the email address of the user you want to delete: ")
    index=0
    for user in u['details']:
        if user['email'] == email:
            u['details'].remove(user)
            print("Deleted")
            break
        else:
            # add the new user to the list of users
            pass
    # Open the JSON file in write mode and write the updated list
    with open('userinfo.json', 'w') as f:
        json.dump(u, f)
a = input("if you want to add press a, if you want to delete press d: ")
if a.lower() == 'a':
    add()

elif a.lower() == 'd':
    delete()
else:
    print("invalid choice!")